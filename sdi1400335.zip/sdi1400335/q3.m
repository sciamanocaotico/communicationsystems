%%%%%%%%%%% EXPERIMENTAL BOX %%%%%%%%%%%

M=2000;
N=2000;

R_1=-1;
R_2=1;

M1= 1;
M2=530;
M3=800;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%formula X= (b-a ).* rand ( . ..(0 , 1) ...) + a
% gives a uniformed distribution in the range  (  a b)
% thus , we should use this one instead to get a distribution in  (-1,1)
% X =(R2 - R1) .*rand ( ) + R1

X=(R_2 - R_1) .* ( rand (M,N) )  +R_1;

%for each of  i = 1 , 530 and 800 we get observations for 2ooo  moments
% so we have 3  random variables according to definition of a ran. process


vis1=X(M1, :);
vis2= X(M2,:);
vis3= X(M3,:);

X1=vis1;
X2=vis2;
X3=vis3;





%%%%%%%%%CONTROL BOX %%%%%%%%%%%%%

% lets plot something just so we can observe later the statistical values
% and have a better view while visualize them
figure('NumberTitle', 'off', 'Name', 'Question 3.B');
subplot ( 3, 1,1)
plot ( vis1)
title( " Xi for every N  so i =1 ")



subplot ( 3, 1,2)
plot ( vis2)
title( "  Xi for every N  so i =530  ")


subplot ( 3, 1,3)
plot ( vis3)
title( " Xi for every N  so i =800 ")


avgx1=mean(X1);
avgx2=mean(X2);
avgx3=mean(X3);

variationx1=var(X1);
variationx2=var(X2);
variationx3=var(X3);
 display ( '    MEAN  | VARIATION ') 
 t="| ";
msrs1=[ avgx1,variationx1]
msrs2=[ avgx2,variationx2]
msrs3=[ avgx3,variationx3]

display ( " We can see that almost always")
display(" mean is 0 for 2.ooo observations" )
display ( " and variation very close to 1/3 ")
display("  as expected from our formula" )



figure('NumberTitle', 'off', 'Name', 'Question 3.E');


subplot ( 3, 1,1)
hist(X1,125)
title ( "hstgramX1 ( i =1) " ) 

subplot ( 3, 1,2)
hist(X2,125)
title ( " hstgram X2 ( i =530) " ) 

subplot ( 3, 1,3)
hist(X3,125)
title ( "hstgram X3 ( i =800) " ) 

  