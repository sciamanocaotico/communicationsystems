function [y]= pla(x)
y = x.^3 + 3 *x.^2 + 1;
end