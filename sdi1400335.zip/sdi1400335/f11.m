function [yy]= f11(t)
     
if t >= 0 & t < 2
    yy=t;
else if t >=2 & t <4
        
        yy=1/ ( 2* (3-2*t) ) ;
    else
        yy=0;
    end
end

    