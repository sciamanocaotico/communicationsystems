% This script prints out 2 plots.
% By Using the function evenodd at the same dir it computes 
% one  plot for the even and one for the odd component of the function
% with name that matches the right side of the above line right after @ 
%%%%%
funame= @pla;
%%%%
% You can change the domain of the function  
% by changing the constants in the next line

domain= ( -10:0.1:10);
xev= zeros(size(domain)); 
xod=zeros(size(domain));

piper = functions( funame);
cigar=piper.function;
res=[ 0 , 0];

for i = 1: length( domain);
    [xev(i) , xod(i) ]=evenodd(funame,i);
     
end     


figure('NumberTitle', 'off', 'Name', 'Question 2');
subplot ( 2 ,1 ,1)
plot ( domain , xev)
title ( " Even component of the variable function "+ cigar)



subplot ( 2, 1,2) 
plot ( domain,xod)
title ( " Odd component of the variable function "+ cigar)