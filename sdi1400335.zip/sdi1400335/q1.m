x= [-5:0.01:5];
y = zeros ( size ( x)); 

y2= zeros ( size ( x)); 
y3=zeros ( size ( x)); 

for i = 1: length( x) 
    y(i) = f11( x(i));
    y2(i)= f11 ( 2*x(i) );
    y3(i) = f11 ( x(i) / 2) ;
    
end


%fig1= figure 
%figure ( 'Name', ' Exercise 1') 
%figure ( 'Color' , 'orange')

figure('NumberTitle', 'off', 'Name', 'Question 1');
subplot ( 3,1,1)

plot ( x ,y) 
title( " y= x( t) " )
xlabel( " t") 
ylabel(" x(t)" ) 

subplot ( 3,1,2) 
plot  ( x, y2)
title ( " y = x(2t) ") 
xlabel ( " t " )
ylabel ( " x(2t) " )

subplot ( 3,1,3) 
plot ( x , y3) 
 title ( " y =x( t/2) ") 
 xlabel ( " t " )
 ylabel  ( " x(2t) " )
 
