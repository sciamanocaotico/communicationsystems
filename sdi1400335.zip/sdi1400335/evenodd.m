function [ye,yo]=evenodd(func1,t)
% returns an array of 2 one for each component of
% the function << func1 >>  at the spot << t >> 

a= func1(t);
b= func1(-t);

ye=0.5* ( a + b );
yo=0.5* ( a- b);

end